# ifix-vpn-subs

Subscription file for **IFIXVPN**.

## servers.txt
Raw share links (`ss://`, `vmess://`, …) one per line.

## Auto health check
GitHub Action runs every **3 hours** (and manually):

1. TCP-connect test to each config host:port  
2. Sort live servers by lowest latency  
3. Keep unreachable lines at the bottom (does not delete them)  
4. Write `health-report.md`

### Manual run
GitHub → **Actions** → **Health Check servers.txt** → **Run workflow**

### Local
```bash
python scripts/health_sort.py
```
