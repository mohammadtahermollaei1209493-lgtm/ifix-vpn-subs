# IFIXVPN health report

- Updated: **2026-09-12 10:36 UTC**
- Total: **12**
- Live (TCP): **12**
- Unreachable: **0**
- Mode: `keep dead at bottom`

| Status | Proto | Host:Port | Latency |
|--------|-------|-----------|---------|
| OK | vmess | `81.28.9.171:46464` | 93.2 ms |
| OK | vmess | `81.28.9.186:46464` | 93.7 ms |
| OK | ss | `81.28.9.186:25858` | 93.9 ms |
| OK | ss | `81.28.9.171:25858` | 94.6 ms |
| OK | vmess | `81.28.9.55:46485` | 96.3 ms |
| OK | ss | `81.28.9.167:25858` | 96.6 ms |
| OK | vmess | `81.28.9.186:46485` | 96.7 ms |
| OK | vmess | `81.28.9.167:46464` | 97.1 ms |
| OK | vmess | `81.28.9.171:46485` | 97.3 ms |
| OK | ss | `81.28.9.55:25858` | 97.4 ms |
| OK | vmess | `81.28.9.167:46485` | 97.7 ms |
| OK | vmess | `81.28.9.55:46464` | 100.9 ms |
